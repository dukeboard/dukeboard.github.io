package org.kevoree.library.javase.helloworld;

/**
 * Created by IntelliJ IDEA.
 * User: gnain
 * Date: 27/10/11
 * Time: 14:36
 */
public interface HelloProductionListener {

    public void helloProduced(String helloValue);
}
